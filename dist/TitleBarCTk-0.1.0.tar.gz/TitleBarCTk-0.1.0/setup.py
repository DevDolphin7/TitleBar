from setuptools import setup

setup(
    name='TitleBarCTk',
    version='0.1.0',
    install_requires=[
        'pywin32',
        'screeninfo',
        'pillow',
        'customtkinter',
    ],
)
